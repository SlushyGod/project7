# Project 7 - WordPress Pentesting

Time spent: **12** hours spent in total

> Objective: Find, analyze, recreate, and document three vulnerabilities affecting an old version of WordPress

## Pentesting Report

1. CVE-2015-8834
  - [2015-8834] Summary:
	Cross-site scripting (XSS) vulnerability in wp-includes/wp-db.php in WordPress before 4.2.2 allows remote attackers to inject arbitrary web script or HTML via a long comment that is improperly stored because of limitations on the MySQL TEXT data type. NOTE: this vulnerability exists because of an incomplete fix for CVE-2015-3440.
    - Vulnerability types: Cross Site Scripting
    - Tested in version: 4.2
    - Fixed in version: 4.2.2 
  - [2015-8834] GIF Walkthrough:
	Vuln1.png
	This image shows that the cross site scripting has posted malicious tags
  - [2015-8834] Steps to recreate:
	This attack focuses on two things. 1 that the comments are being filtered for certain attacks but allow <a></a> link tags. 2 that after looking for these tags the comment is added to a databse of 64 kB and if there is anything more than that then it is truncated. To recreate add this in the comment box and send:
<a title='hello   onload=javascript:alert(1) style=position:absolute;left:0;top:0;width:5000px;height:5000px     AAAAAA...enough bytes to be longer than 64kB...AAA'></a>
	After sending this it will pass the first filter, but it will be truncated at the ending link. This will cause the link tag to be open and force the browser to interpret the meaning of the text. This allows malicious posts to be added to the website.
- [Link 1](https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2015-8834)

2. CVE-2015-3429
  - [2015-3429] Summary:
	Cross-site scripting (XSS) vulnerability in example.html in Genericons before 3.3.1, as used in WordPress before 4.2.2, allows remote attackers to inject arbitrary web script or HTML via a fragment identifier.
    - Vulnerability types: XSS, DOM
    - Tested in version: 4.2
    - Fixed in version: 4.2.2
  - [2015-3429] GIF Walkthrough:
	Vuln2.1.png
	Create a link that isn't suspicious
	Vuln2.2.png
	The javascript is activated
  - [2015-3429] Steps to recreate:
	Use netbeans to create a link that will get an admin thats logged in to click. Use this code to create the link: <a href="http://wpdistillery.vm/wp-content/themes/twentyfifteen/genericons/example.html#1<img/ src=1 onerror=alert(1)>">Super Safe Link</a>
  - [2015-3429] Affected source code:
	added{+**3.3.1**
	+
	+Security Hardening: Remove Genericons example.html file. Please visit genericons.com instead.
	+}
    - [Link 1](https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2015-3429)

3. CVE-2017-6819
  - [2017-6819] Summary:
	In WordPress before 4.7.3, there is cross-site request forgery (CSRF) in Press This (wp-admin/includes/class-wp-press-this.php), leading to excessive use of server resources. The CSRF can trigger an outbound HTTP request for a large file that is then parsed by Press This.
    - Vulnerability types: CSRF, DOS
    - Tested in version: 4.2
    - Fixed in version: 7.7.3
  - [2017-6819] GIF Walkthrough:
	Vuln3.1.png
	Create a link to the site that has the DOS content
	Vuln3.2.png
	The site has been loading for 3 minutes
  - [2017-6819] Steps to recreate:
	Used the Press This function that allows looking for embedded content and then directly uploads it to the admins site. Only the admin can do this, however there is a csrf vulnerability. Create a link that admins will clink on to a site that links to a page with tags like this:
	<img src="http://wpdistillery.vm/wp-admin/press-this.php?u=localhost%2Fbigfile.txt&url-scan-submit=Scan&a=b">
	<img src="http://wpdistillery.vm/wp-admin/press-this.php?u=localhost%2Fbigfile.txt&url-scan-submit=Scan&a=c">
	Note that linking to a larger file with actuall embedded content will extend the DOS. Also adding more of the image tags will lengthen the attack.
  - [2017-6819] Affected source code:
    - [Link 1](https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2017-6819)

## Assets

Netbeans IDE to create links and CSRF forms
XAMPP to set up a local server to launch the attack
Wpscan to list the known vulnerabilities in wordpress

## Resources

- https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2015-8834
- https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2015-3429
- https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2017-6819


## Notes

Some challenges with finding vulnerabilities was understanding what some of the vulnerabilities were with the limited notes that were given. The thing that worked the most was looking at the php code and figuring out the vulnerability through how they fixed the code.


## License
Vagrant:
The MIT License

Copyright (c) 2010-2018 Mitchell Hashimoto

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.